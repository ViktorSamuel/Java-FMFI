package matches;

import java.io.PrintStream;
import java.util.Scanner;

public class HumanPlayer implements Player {
    Scanner scanner;
    PrintStream out;
    public HumanPlayer(Scanner scanner, PrintStream out){
        this.scanner = scanner;
        this.out = out;
    }
    @Override
    public int take(int totalMatches, int maxMatches){
        out.print("Zadaj pocet zapaliek: ");
        int n;
        do{
            n = scanner.nextInt();
            return n;
        }
        while (n < 1 || n > maxMatches);
    }
}
