package matches;

public class MinimalisticPlayer implements Player{
    @Override
    public int take(int totalMatches, int maxMatches){
        return 1;
    }
}
