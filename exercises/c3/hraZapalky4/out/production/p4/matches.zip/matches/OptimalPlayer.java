package matches;

public class OptimalPlayer implements Player{
    @Override
    public int take(int totalMatches, int maxMatches){
        for(int i = 1; i <= maxMatches; i++) {
            if((totalMatches-i) % maxMatches == 1) return i;
        }
        int n = 1;
        while (n < maxMatches) n++;
        return n-1;
    }
}
