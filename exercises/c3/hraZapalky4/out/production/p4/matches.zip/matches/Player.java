package matches;

public interface Player {

    int take(int totalMatches, int maxMatches);

}
