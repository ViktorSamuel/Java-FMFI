package robots;
public class CowardProgrammedRobot extends ProgrammedRobot{
    int comandCount;
    public CowardProgrammedRobot(String[] comands){
        super(comands);
        this.comandCount = comands.length;
    }
    @Override
    public String nextAction(View view) {
        for(int i = 0; i < comandCount; i++){
            StringBuilder str = new StringBuilder();
            str.append(super.nextAction(view));
            if(str.toString().equals("UP") && view.getUp().isAccessible()) return "UP";
            if(str.toString().equals("RIGHT") && view.getRight().isAccessible()) return "RIGHT";
            if(str.toString().equals("DOWN") && view.getDown().isAccessible()) return "DOWN";
            if(str.toString().equals("LEFT") && view.getLeft().isAccessible()) return "LEFT";
            if(str.toString().equals("SKIP")) return "SKIP";
//            switch (super.nextAction(view)){
//                case "UP":
//                    if(view.getUp().isAccessible()) return "UP";
//                case "RIGHT":
//                    if(view.getRight().isAccessible()) return "RIGHT";
//                case "DOWN":
//                    if(view.getDown().isAccessible()) return "DOWN";
//                case "LEFT":
//                    if(view.getLeft().isAccessible()) return "LEFT";
//                case "SKIP":
//                    return "SKIP";
//            }
        }
        return "SKIP";
    }
}
