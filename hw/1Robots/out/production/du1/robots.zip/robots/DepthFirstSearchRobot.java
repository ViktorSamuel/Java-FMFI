package robots;
public class DepthFirstSearchRobot implements Robot{
    private String[] commands = {"UP", "RIGHT", "DOWN", "LEFT"};
    private int opositeComand;
    private int n = 0;
    public DepthFirstSearchRobot(){
        this.opositeComand = -1;
    }
    @Override
    public String nextAction(View view) {
        n++;
        if(n % 2 == 1) return "PUT "+opositeComand;
        if(view.getUp().isAccessible() && view.getUp().getRecord() == 0) {
            opositeComand = 2;
            return "UP";
        }
        else if (view.getRight().isAccessible() && view.getRight().getRecord() == 0) {
            opositeComand = 3;
            return "RIGHT";
        }
        else if (view.getDown().isAccessible() && view.getDown().getRecord() == 0){
            opositeComand = 0;
            return "DOWN";
        }
        else if (view.getLeft().isAccessible() && view.getLeft().getRecord() == 0) {
            opositeComand = 1;
            return "LEFT";
        }
        else if (view.getUp().getRecord() != 0 || view.getRight().getRecord() != 0
            || view.getDown().getRecord() != 0 || view.getLeft().getRecord() != 0) {
            return commands[view.getHere().getRecord()];
            //return commands[opositeComand];
        }
        else return "SKIP";
    }
}
