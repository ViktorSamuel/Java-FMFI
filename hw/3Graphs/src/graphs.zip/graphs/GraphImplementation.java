package graphs;

public enum GraphImplementation {
    LISTS, MATRIX
}